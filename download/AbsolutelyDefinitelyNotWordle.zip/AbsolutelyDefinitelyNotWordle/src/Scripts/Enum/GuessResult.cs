public enum GuessResult
{
    Default = -1,
    Correct,
    Incorrect,
    Appears
}
